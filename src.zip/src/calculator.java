import java.util.Scanner;

public class calculator {
    public static  void main(String args[]){
        Scanner sc = new Scanner(System.in);

        System.out.print("enter the first number: ");
        double num1 = sc.nextDouble();

        System.out.print("enter the second number:");
        double num2 = sc.nextDouble();

        System.out.println("Sum " + "=" + (num1 + num2));
        System.out.println("Difference " + "=" + (num1 - num2));
        System.out.println("Product " + "=" + (num1 * num2));
        if (num2 != 0)
            System.out.println("Quotient " + "=" + (num1 / num2));
        else
            System.out.println("can't divide by zero");
    }
}